# Independent Unpruned FIFO Gate v6

Fixed 2026-10-13 before execution. Preserve the v4 quantifier-budget failure
and v5 partial nested-recurrence gate. V5 completed 12/32 inputs, 465 full
three-method states and 427 query tuples; 20 input subtests stopped at UNKNOWN
timeouts, plus the final coverage assertion failed. No SAT set-difference
counterexample was returned. It is not a passed full gate.

This new gate keeps exactly the same first block's 32 cells, 688 states and
656 queries. It changes the independent oracle expression, not any measured
method, timeout, input, outcome or subset. Retain every possible FIFO branch:

D_c = max over k<c of (t_k + delta + theta * sum(p_i, i=k,...,c-1)).

The identity follows by induction from D_c=max(D_(c-1),t_(c-1)+delta)+theta*p_(c-1).
Adding theta*p to a maximum adds it to every branch, and the new arrival adds
the last branch. The c=1 identity is immediate. This algebraic identity does
not depend on hull pruning, geometry or solver performance. The oracle code
uses backward rational sums, retains all c branches, and imports no departure
envelope builder. Do not label this as completing every literal nested-ITE
check. It is a separately constructed unpruned equivalent formula.

Completed facts become a conjunction over all branches, unfinished facts a
strict disjunction, and new-request predicates include both every D_n branch
and now+delta. Use exact independently eliminated generator priors as in v5.
Require every whole-set difference UNSAT and both query predicates equal for
live and saved methods. Each check still has a 1000 ms budget; the whole
validation cap is 900 s. Any UNKNOWN fails. No timing acquisition is rerun.
