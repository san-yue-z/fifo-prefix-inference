# Exact Rational Resolution of Pending Structural Sets

Fixed 2026-10-13 before execution. The v4/v5/v6 outcomes and all timing
acquisitions remain immutable. Select the six unfinished v6 first-block inputs
by absence from its completed-input observations, not by timing performance.
Validate every initial and subsequent state and query of all six inputs, not
only the location where the earlier solver stopped: 153 states and 147 queries.

Use an independent standard-library rational checker. For each departure
count, retain all FIFO affine branches from backward sums. Determine a branch's
active theta interval by intersecting all pairwise affine-dominance inequalities.
This uses no persistent hull, geometric clipping or SMT solver. Check interval
coverage. At each theta used for set comparison, evaluate the literal FIFO
recurrence, not the active-branch representation.

Verify EnvelopeSMT's actual initial assertions against the original halfplanes
and domain. Verify every retained report assertion's syntax against its cached
affine terms. Each cached term must be an original FIFO branch and all branches
active on an open theta interval must be retained. Continuity proves endpoint
coverage; singleton scopes are checked directly. Thus the whole retained SMT
formula is independently equal to the literal specification within its bounded
original prior, without repeating a large SMT equivalence check.

For Band and Planar, read their exposed exact geometric representations and
derive vertical intervals independently. Form all relevant affine boundary
segments, including strict facets, point/segment equalities, theta-only
restrictions, departure kinks and query thresholds. Clip segment domains to a
shared bounding rectangle, add segment endpoints and every pairwise crossing
within overlapping domains. Check exact interval-union equality at every
critical theta and a rational midpoint in every intervening open interval.

Between those theta events, active affine boundaries have a fixed vertical
order, and all Boolean membership relations and strict flags are constant in
the resulting strata. Equality of the normalized interval unions at a midpoint
therefore proves equality throughout that interval. At crossings/endpoints,
compare exact slices separately. This is an exhaustive finite decomposition,
not an unstructured sample grid. Bounds are derived from priors and all exposed
representations; outside the rectangle every compared set is empty. Confirm
that the original SMT prior is unchanged, and that its closure matches the
declared convex vertices, before using this boundedness fact.

Derive both query-existence flags from the same exact strata and the literal
FIFO readiness. Include the query boundary lines in the event arrangement.
Compare exact threshold, action and mode with all three live untimed methods
and saved acquisitions. Preserve a transcript hash for every state. Require
all coverage and equality checks, with no tolerance or floating point. The
external process cap is 900 s; failures remain failures, with no silent retry.

First run analytic controls for interval unions, strict ties, singleton slices,
dominance certificates, AST conversion and polygon/segment/point facets.
This checker is classical rational line-arrangement reasoning, not a new
paper algorithm, performance measurement, general program proof or novelty
clearance. Its success would resolve the six selected finite input histories
by a different proof construction; it would not change v6's recorded UNKNOWNs.
