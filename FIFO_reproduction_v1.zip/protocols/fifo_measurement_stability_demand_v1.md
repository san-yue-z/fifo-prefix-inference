# Fixed-Instance Measurement Stability and Query Demand

This protocol is fixed on 2026-10-13 before the new acquisition. It addresses
measurement repeatability and workflow dependence, not population inference,
whole-method novelty or deployment reliability. The original 192-input
acquisition and every measured implementation remain unchanged.

## Selection and Fixed Workflows

Select six distinct original inputs, in this order, using the saved original
costs and diagnostics only: strongest Planar/Band reversal; Planar/Band nearest
one; strongest SMT/Band reversal; SMT/Band nearest one; greatest minimum of
the two baseline/Band ratios; and greatest observed Band bands-plus-points
count. Break ties by input identifier, and take the next eligible input when a
previous rule already selected one. This intentionally outcome-stratified
subset is not representative of the 192-input distribution.

For each selected input, retain its original jobs, actual strict prior and all
original facts for the `original` history. A second `before_terminal` history
keeps only the initial stages preceding its first full-completion report. It
does not include that report or a subsequent contradictory report. The full
ledger remains unchanged. This is an explicit different feedback pattern,
not a claim to broader prior geometry or hidden-work robustness.

After each retained report, request 1, 4 or 16 certificates. The first query
is byte-identical to the corresponding original query. Further hypothetical
alternatives use the same query time, positive work cycling through
{1/2,3/4,5/4,3/2}, and small fixed rational additions to the original local
duration and deadline. They are alternative assessments of one snapshot,
not a sequence of dispatched requests. No query appends work or supplies the
generating parameter. The generated input file records every exact argument.

Each of the 36 input/history/demand cells is repeated six times, using each
permutation of the three method orders once on the identical workflow. All
actors are freshly constructed for each method in each repetition. Cells are
interleaved by repetition, with a fixed rotation of cell order; the input file
fixes the complete acquisition order. There are 216 paired workflows and 648
planned controllers. No timings have been inspected when this plan is fixed.

## Measurement and Failure Handling

Use the unchanged Band v2, Planar v2 and EnvelopeSMT v2 implementations and
the same Python 3.12 and native Z3 runtime as the original comparison. Charge
construction, every update and every complete query, including guards and
solver checks. Import/global startup, raw recording and diagnostics are
outside algorithm-call cost. Record exact timer endpoints and every outcome.
SMT uses its retained solver, two existence checks, no model extraction and
the unchanged 1000 ms per-check timeout. Stop the owned acquisition process
at an external 900 s cap. Preserve ERROR, UNKNOWN, partial and NOT_RUN stages;
do not retry or select the best run. Every denominator remains visible.

Record the current CPU, physical memory, operating system, Python/Z3 versions
and active power scheme before and after this acquisition where available.
These observations describe the new campaign, not undocumented conditions
of the previous campaign. There is no processor affinity, temperature or
frequency trace, dedicated-idle guarantee or worst-case latency guarantee.
Do not run document rendering or other owned compute jobs during acquisition.

## Analysis and Scope

Independently reconcile raw stage endpoints, stage order, full costs, planned
inventory and both query predicates/threshold/action/mode. For each fixed
cell report all six paired cost ratios, median and full range, the method
fastest in each repetition and per-method median, min, max and median
absolute deviation. These repetitions quantify measurement dispersion on
fixed instances, not independent deployment draws; no population confidence
interval, p value or significance claim is authorized. Report all reversals.

Keep the original 177/192 winner count explicitly attached to its original
single acquisition. Do not pool this outcome-selected campaign with those
192 inputs. Repeated-query costs are acquired, not reconstructed by multiplying
the old query sums. General difficult-support scalability remains untested.
