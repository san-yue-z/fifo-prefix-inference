# Post-Acquisition Large-History Literal Gate v4

Fixed 2026-10-13 after the v2 cost acquisition but before this correctness
execution. This is verification, not a new timing confirmation. No cost
samples, actor sources or acquired inputs are changed or rerun for timing.

Select the first fixed generation block 2026101301: all 32 factorial cells,
not a performance-dependent subset. For both original prior descriptions,
existentially eliminate independent convex-combination weights. For every
initial and report-updated state in these inputs, require full continuous-set
XOR equality of all three strengthened methods and the literal nested FIFO
recurrence. Evaluate both literal query predicates at every recorded query,
then compare all three live untimed methods and all three saved results.

There are 688 selected history states and 656 query tuples. Every elimination,
set check and literal query check has a 1000 ms timeout. UNKNOWN, SAT set
differences, unclassified queries, missing recorded counterparts or exceptions
fail this gate. Preserve outcomes without overwriting previous gates. The
external validation process has a 900 s wall-clock cap. Validation calls are
not new performance measurements and do not make this a general proof.
