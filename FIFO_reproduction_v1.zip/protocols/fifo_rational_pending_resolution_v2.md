# Rational Pending Resolution v2

Fixed 2026-10-13 before execution. Preserve v1 and its failure: all 12 analytic
controls passed, but its initial SMT-assertion comparison incorrectly
distinguished theta>0 from 0<theta. A read-only diagnostic reproduced the
different AST encodings. No set-arrangement check had completed.

V2 retains the exact same six inputs, 153 full states and 147 queries, rational
decomposition, 900 s external cap and all v1 proof obligations. Only normalize
comparison operands/sign and nonzero rational scale for the retained-assertion
syntax proof, and treat conjunction/disjunction order as irrelevant. This is
an exact algebraic equivalence, not a relaxed equality tolerance. Add explicit
tests that equivalent directions/scales match and strictness differences do
not. All previously measured algorithms and data are unchanged.

The standard-library interval/dominance/arrangement implementation remains
the immutable v1 module. V2's source and both modules are hashed. The original
pending-resolution protocol applies except for this documented AST repair.
No old acquisition is rerun for timing; preserved UNKNOWN gates stay UNKNOWN.
