# Comparable Methods Correctness Gate v3

Fixed 2026-10-13 before executing the strengthened methods or recording new
costs. The existing 20-case analytic corpus is unchanged. It includes points,
segments, multiple components, strict facets, excluded equality, readiness
kinks, out-of-order reports, contradictions and deadline-bound outcomes.

For every initial and subsequent history state, compare the entire continuous
parameter set of TightBandPosterior, FacetPlanarPosterior and
CompletionEnvelopeSMT with a literal, uncompiled FIFO recurrence. The oracle
prior uses convex-combination generator weights eliminated by exact linear
real quantifier elimination. Each complete-set symmetric difference must be
UNSAT. SAT, UNKNOWN, residual quantifiers, exceptions or altered sources fail.

The SMT method consumes halfplanes, not vertices. Independently convert the
raw ordered convex vertices to weak point/segment/polygon constraints and add
the corpus's original strict constraints. Initial-state set equality checks
this conversion as well as the method. Do not silently use unbounded priors.

For each case's final query, independently evaluate both existence predicates
using the literal FIFO recurrence, including equality on the remote side.
Compare predicates, action, mode and exact threshold for all three methods.
Also check common physical clock/work guards and report-count guards.

Timeout is 1000 ms for each oracle elimination/check and each SMT existence
check. Preserve failures in a new output directory; never overwrite an older
gate. Record source hashes before and after. This is finite input-specific
correctness evidence, not general verification, performance, novelty or
publication qualification. No previous cost acquisition is rerun.
