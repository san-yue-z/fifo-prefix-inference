# Fixed-Instance Demand Figure Contract

Core conclusion: the complete-workflow ordering depends on query demand;
large original advantages can persist while ties and reversals require
instance-specific interpretation. The data are the separately acquired six
fixed inputs, two received-history patterns, three query demands and six
balanced-order repetitions per condition, never reweighted old timings.

Use the already established Python/matplotlib backend. One quantitative
six-panel grid has a shared paired comparator/Band ratio scale: S1 checks an
original Planar reversal; S2 a near Planar tie; S3 an SMT reversal; S4 a near
SMT tie; S5 a large joint Band advantage; S6 the largest eligible observed
support. This panel family shows the declared selection heterogeneity, not
six interchangeable repetitions of a population claim.

Each marker is a median of six paired ratios and each vertical whisker is
their full observed minimum/maximum. No confidence intervals or p values.
Both comparators and both history patterns appear in every panel. Original
input selection is outcome-stratified and disclosed; it is not representative.
No exclusions from the 36 audited cells. All 216 raw paired observations
remain in the source table and all min/max endpoints must fit the plot.

Export a 165 x 128 mm PDF/SVG with editable text and 600 dpi PNG/TIFF. Fonts
are at least 7 pt. Keep equal plot rectangles, consistent labels, a neutral
ratio-one line, restrained comparator colors and pattern-specific line styles.
Run source, rendered alignment, PDF glyph and collision audits, then visually
inspect all six panels and the assembled figure at its final physical size.
The figure is empirical workflow evidence, not correctness or novelty proof.
