# Rational Pending Resolution v3: Interface Repair

Fixed 2026-10-13 before execution. V2's 15 analytic controls and the first
complete retained-SMT assertion certificate passed. The recorder then stopped
because the v2 wrapper omitted the formula_slice export. Preserve this failure;
it is an integration error of the new checker, not a set difference or an
inference-algorithm change.

V3 adds the missing export without changing interval, arrangement, dominance
or normalized-assertion logic. Add a complete interface inventory and a small
frontend integration test before the six histories. The original protocols
still apply: exactly six pending inputs, all 153 states and 147 queries, exact
arithmetic, no performance retiming, no changed acquisition, and a 900 s cap.
All three checker modules, every test and recorder dependency are hashed.
