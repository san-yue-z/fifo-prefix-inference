# Comparable Methods Prospective Strengthening

Fixed 2026-10-12 before any new cost measurement. Original Band, Planar v1,
EnvelopeSMT and all recorded acquisitions remain unchanged.

Planar v1 unnecessarily split the completed side over every departure branch
and then rejoined convex pieces. Since a completed maximum <=tau is a flat
conjunction, v2 clips each current convex cell directly with all affine
branches. The unfinished side still uses ordered active-branch partitions,
with conservative whole-cell true/false checks. It retains exact joins and
uses closure-vertex query witnesses before clipping. Thus the planned baseline
does not pay avoidable convex fragmentation costs.

Band v2 crops each component's curve-extraction scope to the closure of its
current surviving support, retaining isolated point slices. This is an exact
consequence of intersection-only updates. It does not alter old measured code,
expand support or justify change-output-sensitive runtime.

All three v2 methods exploit the same public full-completion fact. If a report
states c=n at tau<=now, then D_n=delta+g_n<=tau and delta>=0 imply g_n<=now.
Remote readiness therefore equals now throughout the feasible parameter set.
Empty sets remain empty, and the as-of guard precedes this simplification.
Do not exploit this shortcut for one side of a comparison only.

Before timing, require continuous full-set equality and both query predicates
on the fixed analytic corpus against literal FIFO, including strict equality,
contradictions and deadline-bound outcomes. UNKNOWN fails the correctness gate.
The SMT interface retains one solver and two existence checks, no model or
witness extraction. Completed/unfinished report constraints and original prior
information must be identical. Setup, update and complete query costs are all
charged. No speedup, best-in-class geometry claim, novelty clearance or SCI
qualification is supplied by this strengthening design.
