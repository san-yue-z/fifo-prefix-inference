# Prospective Structural Comparison v2

## Material Passport

- Artifact: deterministic single-PC algorithm comparison plan.
- Date fixed: 2026-10-13, before input generation and any acquisition.
- Purpose: test whether the vertical-profile implementation has an informative
  cost advantage over strengthened exact planar and flat-envelope SMT methods.
- Data class: synthetic rational queue facts; no robot, human or physical GPU
  inference observations. No external upload.
- Approval scope: the user's request explicitly authorizes writing and running
  experiment code. No journal-quality or publication outcome is presumed.

## Methods And Common Information

TightBandPosterior, FacetPlanarPosterior and CompletionEnvelopeSMT from
shared_scale_comparable_methods_v2.py. All use the identical finite ledger and
original joint prior, only already delivered count facts, and identical query
arguments. All exploit a received full-completion report after its as-of time.
No nominal generating parameter or future report is passed to an actor.

The v3 fixed continuous-set/query correctness gate must have passed with
unchanged actor sources before acquisition. It is finite correctness evidence,
not a general proof. New agreement is checked on every completed paired query.

## Fixed Inputs

Full factorial: n in {32,128}; m in {8,32}; prior components C in {1,4};
submission precision b in {8,40}; history family in {consistent,contradictory}.
Six fresh blocks 2026101301--2026101306 give 192 inputs and 576 controllers.
Every factorial cell runs all six permutations of the three method orders,
one order per block. Factorial order within each block is deterministic.

Heterogeneous work is drawn from {1/2,3/4,1,5/4,3/2}. Exact intersubmission
gaps are 1/2 plus a SHA-256 counter draw in {0,...,256}/256. The 40-bit condition
adds an odd draw in {1,...,255}/2^40. Matching factorial cases use the same
macro ledger. This changes numerical values slightly as well as precision;
it is not an isolated causal effect of arithmetic representation.

One-component prior: theta in [1/2,3/2] and
delta in (s*(theta-1/2), 7/8+s*(theta-1/2)], s=1/8.
Four components: lower offsets i/4 and width 1/8 for i=0,...,3 with the same
slope; lower facet strict for even i, upper facet strict for odd i. Vertices
describe weak closures, and explicit halfplanes describe actual strict sets.
Both priors share a bounding box, but have different area and information.
Changing C is not an isolated complexity experiment.

Nominal generation witness theta=1, delta=5/8. At report j=0,...,m-1 use
c=floor(j*n/(m-1)), including c=0 and c=n. For c<n use the midpoint between
D_c and D_(c+1), with tau=D_1/2 for c=0. For c=n use tau=D_n+1/4. Exact
literal FIFO arithmetic verifies every count. Query now is the maximum of
last submission+1/16, tau+1/16 and previous now+1/16.

Cycle queries: (local duration,deadline offset) = (3/2,3),(3,4),(4,2), all
with new work=1. The third query genuinely binds the deadline and makes the
local fallback untimely. A contradictory family appends c=0 at the final c=n
timestamp, then queries later; it has m+1 reports, not m. The contradiction
does not depend on any generating parameter and necessarily yields EMPTY.

## Acquisition And Denominators

One acquisition per generated input, no timing-based resampling or best-of
selection. Same CPython 3.12 runtime and Z3 5.1 as the recorded comparisons.
Import/global context startup are outside timing. Full algorithm-call cost
is constructor plus every successful/unsuccessful update and complete query
call, including parsing, hull construction and solver checks. Event recording
and representation diagnostics are outside this cost. Operational controller
elapsed time is recorded separately and is not deployment latency.

SMT uses a retained solver, 1000 ms per existence check, no witness extraction.
The external acquisition process has a 900 s wall-clock cap. Preserve ERROR,
UNKNOWN, partial controllers and NOT_RUN stages. Never impute failed timings.
Do not silently retry. Analyze all planned inputs and report eligible paired
denominators before any conditional cost ratio.

No processor affinity, thermal/frequency trace, dedicated idle machine or
real-time worst-case guarantee is available. Six blocks are different inputs,
not six timing replications. Report per-input costs and descriptive stratified
summaries; do not use these blocks as a broad deployment population sample.

## Scientific Gate

Inspect both competitors, reversals, overheads, mixed/deadline/empty outcomes,
representation size and observed integer bit lengths. Positive timing alone
does not resolve the outstanding originality concern. Negative outcomes are
retained and may require changing the first-paper problem rather than wording
around them. Keep previous sources, measurements, reviews and paper intact.
