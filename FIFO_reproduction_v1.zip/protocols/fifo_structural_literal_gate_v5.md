# Large-History Literal Gate v5: Componentwise Prior Elimination

Fixed 2026-10-13 before this new correctness execution. The v4 gate is retained:
its four-component union elimination left a quantifier after the 1000 ms
budget, so no large-history actor or set checks had run. This is an oracle
construction limitation, not an observed actor counterexample or a passed gate.

Keep the same first fixed block, all 32 cells, 688 complete history sets and
656 query tuples. Change only construction of the identical oracle prior:
eliminate convex-combination weights separately inside each component before
disjoining the resulting formulas. Existential quantification distributes
over a finite disjunction; each branch uses only its own generator weights.
Require all component results to be quantifier-free, then add theta>0 and
delta>=0. Original strict constraints and every raw vertex remain present.

Every component elimination and solver check still has a 1000 ms budget. All
three live and saved methods must agree with every literal query predicate,
and all three complete-set differences must be UNSAT for every selected
history state. The external process cap remains 900 s. Preserve v4 and v5
outcomes separately. No performance resampling or actor-source change.
