# FIFO Parameter Inference Reproduction Archive

This private archive contains code, fixed synthetic inputs, original recorded
measurements, exact-check evidence and documentation for FIFO parameter inference
from completed-prefix reports. It is not a public data release or a submitted
manuscript. Substantial OpenAI Codex assistance was used in research and code
preparation. Human scholarly review and final submission approval are pending.

## Verify saved records

In this extracted directory, use Python 3.12:

    python scripts/verify_fifo_complete_clean_archive_v3_1.py
    python tests/test_fifo_archive_record_newlines_v1.py

The verifier uses only the standard library. It checks this package's manifest,
reconstructs four saved-record CSV tables, and checks all 302,369 saved rational
slice lines and 153 per-state hashes. It makes no inference or solver calls and
acquires no new timing samples. Use a fresh extraction for another verification:
it refuses to overwrite an existing completion receipt. Do not delete recorded
acquisition directories or reinterpret this check as a new experiment.

## Evidence map

- protocols/fifo_structural_inputs_v2.json and the structural acquisition/audit
  directories: 192 original inputs, 576 controllers, 24,192 stages and 3,936
  three-method query tuples. Source for Figure 1 and Table B.1.
- protocols/fifo_stability_demand_inputs_v1.json and the stability acquisition/
  audit directories: six outcome-selected inputs, 36 fixed workflows, six
  repetitions each, 648 controllers, 102,168 stages and 29,610 query tuples.
  Source for Figure 2 and Table D.1. Do not pool with the original study.
- src, tests and correctness artifacts: immutable measured methods and finite
  checks. Old failed/incomplete gates are preserved, not relabelled as passing.
- DATA_DICTIONARY.md and RESULT_TABLE_SCHEMAS.json: all 67 CSV field occurrences,
  units, aggregation rules and the exact transcript endpoint-closure convention.

The original study records Band as fastest on 177/192 inputs; competing methods
also win. Repeated-query workflows can favor Planar, and near ties may change
order. Claims concern fixed-ledger exact inference, not physical deployment,
universal fastest performance or robotic-control benefit.

## Reproduce plots or acquire new experiments

With matplotlib 3.11.2, scripts/export_cor_individual_artwork_v4.py regenerates
all eight individual panels from the original stored records into a new output
directory. Arial is preferred, with DejaVu Sans fallback; font/PDF metadata need
not be byte-identical. No font or external plot-QA helper is bundled.

For new inference runs, the measured environment used CPython 3.12.14 and native
Z3 5.1.0. requirements/queue_certificate_runtime_v1.txt pins the recorded Windows
AMD64 solver wheel. Collectors deliberately refuse overwrites. New timing runs
are distinct experiments; preserve the original recorded data and use a separate
workspace for any new acquisition. No additional computer or physical robot was
used in the reported study.

## Privacy and rights

PATH_REDACTIONS.json records 67 local-root replacements in nine diagnostic or
environment files. Only the executable path changes in four JSON metadata files;
the other changes are diagnostic path text. Source code, inputs, raw timer events,
exact transcript and result tables are unchanged. Original byte hashes remain
recorded and full originals are preserved locally. Audits that cite the original
manifest hash describe that original; this derivative has its own package hashes.

No original user Word file, manuscript text, literature full text, internal AI
review report, credential, bundled binary or third-party QA helper is included.
No public licence, public release, DOI, reviewer access or Zenodo connection is
claimed. The author explicitly approved only this private GitHub destination.
